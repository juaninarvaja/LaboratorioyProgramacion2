﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio56;
using System.IO;

namespace IO_Ejericio58
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
