﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BibliotecaSobrecarga;

namespace WindowsFormsApp1
{
    public partial class txtPeso : Form
    {
        public txtPeso()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEuro_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEuroAEuro_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnConverEuro_Click(object sender, EventArgs e)
        {
            string valorEnEuros = txtEuro.Text;
            float eurosFlotante;
            bool esFlotante;
            esFlotante = float.TryParse(valorEnEuros, out eurosFlotante);
            
            if (esFlotante)
            {
                txtEuroAEuro.Text = valorEnEuros;

                Euro Euro = new Euro(eurosFlotante);
                txtEuroADolar.Text = ((Dolar)Euro).GetCantidad().ToString();
                txtEuroAPeso.Text = ((Peso)Euro).GetCantidad().ToString();
            }

        }

        private void btnConvertDolar_Click(object sender, EventArgs e)
        {
            string valorEnDolares = txtDolar.Text;
            float dolarFlotante;
            bool esFlotante;
            esFlotante = float.TryParse(valorEnDolares, out dolarFlotante);

            if (esFlotante)
            {
                txtDolarADolar.Text = valorEnDolares;
                Dolar Dolar = new Dolar(dolarFlotante);
                txtDolarAEuro.Text = ((Euro)Dolar).GetCantidad().ToString();
                txtDolarAPeso.Text = ((Peso)Dolar).GetCantidad().ToString();
            }


        }

        private void btnConvertPeso_Click(object sender, EventArgs e)
        {
            string valorEnPesos = txtPesos.Text;
            float pesosFlotante;
            bool esFlotante;
            esFlotante = float.TryParse(valorEnPesos, out pesosFlotante);
            if (esFlotante)
            {
                txtPesoAPeso.Text = valorEnPesos;
                Peso Peso = new Peso(pesosFlotante);
                txtPesoAEuro.Text = ((Euro)Peso).GetCantidad().ToString();
                txtPesoADolar.Text = ((Dolar)Peso).GetCantidad().ToString();
            }



        }
    }
}
