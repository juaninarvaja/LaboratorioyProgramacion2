﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11
{

    class Program
    {
        static void Main(string[] args)
        {
            //            11.Ingresar 10 números enteros que pueden estar dentro de un rango de entre - 100 y 100.
            //Para ello realizar una clase llamada Validacion que posea un método estático llamado Validar, que
            //posea la siguiente firma: bool Validar(int valor, int min, int max):
            //a.valor: dato a validar
            //b.min y max: rango en el cual deberá estar la variable valor
            int seguir = 0;
            bool auxNumero;
            int numero;
            string strNumero;
            int contador = 0;
            float promedio;
            int flagMinimo = int.MaxValue;
            int flagMaximo = int.MinValue;


            while (seguir < 10)
            {
                Console.WriteLine("ingrese el numero " + seguir + " :");
                strNumero = Console.ReadLine();
                int.TryParse(strNumero, out numero);
                auxNumero = validar(numero, -100, 100);
                if (auxNumero == true)
                {
                    seguir++;
                    contador += numero;

                    if (numero > flagMaximo)
                    {
                        flagMaximo = numero;
                    }
                    if (numero < flagMinimo)
                    {
                        flagMinimo = numero;
                    }
                }
            }

            promedio = (float)contador / 10;
            
            Console.WriteLine("Minimo: " + flagMinimo + " Maximo: " + flagMaximo + "Promedio:" + promedio);
            Console.ReadKey();
        }
        public static bool validar(int numero, int minimo, int maximo)
        {

            if (numero >= minimo && numero <= maximo)
            {

                return true;
            }
            return false;


        }

    }
}
