﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjerciciosClase2
{
    public class MiClasePrueba
    {
        public int valor;
        public static int valorEstatico;
    }
}
