﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjerciciosClase2
{
    class Program
    {
        static void Main(string[] args)
        {
            //MiClasePrueba objetoPrueba = new MiClasePrueba();
            //MiClasePrueba objetoPrueba2 = new MiClasePrueba();
            //objetoPrueba.valor = 2;
            //Console.WriteLine(objetoPrueba.valor);
        
            //Console.WriteLine(objetoPrueba2.valor);
            //MiClasePrueba.valorEstatico = 1;
            //Console.ReadKey();

            Automovil.MostrarCantidadRuedas();
            Console.ReadKey();
            Automovil autoPrueba = new Automovil();
            autoPrueba.velocidadActual = 50;
            Console.WriteLine(autoPrueba.velocidadActual);
            Console.ReadKey();


        }
    }



}
