﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
   
    public partial class FormBoton1 : Form
    {
        public FormBoton1()
        {
            InitializeComponent();
        }

        private void FormBoton1_Load(object sender, EventArgs e)
        {

        }
        public event mensaje MiEvento;
        private void button1_Click(object sender, EventArgs e)
        {
           
                string texto = textBox1.Text;
            foreach (Form hijo in Owner.OwnedForms)
            {
                if (hijo is FormBoton1)
                {
                    MiEvento(this.textBox1.Text); //hace lo mismo que el invoke
                    //MiEvento.Invoke(this.textBox1.Text); // hace lo mismo q el de arriba
                }
            }
        }
    }
}
