using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ejercicio42;

namespace UnitTestProject1
{
  [TestClass]
  public class Prueba
  {
    [TestMethod]
    [ExpectedException(typeof(DivideByZeroException))]
    public void TestTryDivision()
    {
     
      Division.TryDivison(5, 0);
    }
    [TestMethod]
    [ExpectedException(typeof(DivideByZeroException))]
    public void TestDivisonVacio()
    {
      Division div = new Division();
      
    }


  }
}
