using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio42
{
    public class MiExceptcion : Exception
    {
        public MiExceptcion(string message, Exception innerException)
         : base(message, innerException) { }
    }
}
