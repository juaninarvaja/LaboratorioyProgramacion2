using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio42
{
    public class Division
    {
       

        public static int TryDivison(int numero, int divisor)
        {
            try
            {

                return numero / divisor;
            }
            catch (DivideByZeroException e)
            {
                throw e;
                //throw new UnaException(messageCatch + "No se puede dividir por cero", e);
            }
        }
        public Division(int numero) { }
        public Division()
        {
            try {
                float resultado = TryDivison(5, 0);
            }
            catch(DivideByZeroException e)
            {
                throw e;
            }

        }
        public Division(string letra)
        {
            
            try
            {
                Division div = new Division();
            }
            catch (DivideByZeroException e)
            {
                throw new UnaException("Soy una exceptcion", e);
            }

        }

        public void MiMetodo()
        {
            try {
                Division div2 = new Division("dsadsa");
            }
            catch (UnaException e)
            {
                throw new MiExceptcion("Es MIExcpecion", e);
            }


        }


    }
}

