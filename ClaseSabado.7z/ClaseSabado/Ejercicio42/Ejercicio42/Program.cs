﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio42
{
    class Program
    {
        static void Main(string[] args)
        {
            Division div = new Division(5);
            try { div.MiMetodo(); }
            catch (MiExceptcion e)
            {
                Console.WriteLine(e.Message);
                Exception auxEx = e.InnerException;
                while (auxEx != null)
                {
                    Console.WriteLine(auxEx.Message);
                    auxEx = auxEx.InnerException;
                }

            }
            Console.ReadKey();
            

            
           
        }
    }
}
