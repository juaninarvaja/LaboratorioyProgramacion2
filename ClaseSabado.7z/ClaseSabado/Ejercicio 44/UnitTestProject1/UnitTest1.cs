using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ejercicio_37;




namespace UnitTestProject1
{
  [TestClass]
  public class Prueba
  {
    [TestMethod]
    public void CentralitaIntaciaListaLlamadas()
    {
      //arrange

      //act
      Centralita cen = new Centralita();
      //assert
      Assert.AreNotEqual(null, cen.Llamadas);
    }
    [TestMethod]
    [ExpectedException(typeof(CentralitaException))]
    public void TestCentralitaExceptionLocal()
    {
      Centralita Cen = new Centralita();
      Local l1 = new Local("1000", 10, "1254", 12);
      Local l2 = new Local("1000", 10, "1254", 12);

      
      Cen+=l1;
      Cen += l2;

    }
    [TestMethod]
    [ExpectedException(typeof(CentralitaException))]
    public void TestCentralitaExceptionProvincial()
    {
      Centralita Cen = new Centralita();
      Provincial p1 = new Provincial("100", 15, "200", Provincial.Franja.Franja_1);
      Provincial p2 = new Provincial("100", 15, "200", Provincial.Franja.Franja_1);


      Cen += p1;
      Cen += p2;

    }

    [TestMethod]
    public void TestCentralitaExceptionProvincialyLocales()
    {
      Centralita Cen = new Centralita();
      Provincial p1 = new Provincial("100", 15, "200", Provincial.Franja.Franja_1);
      Provincial p2 = new Provincial("100", 15, "200", Provincial.Franja.Franja_1);
      Local l1 = new Local("100", 15, "200", 12);
      Local l2 = new Local("100", 15, "200", 12);
      
      Assert.AreEqual(true, p1 == p2);
      Assert.AreEqual(true, l1 == l2);
      Assert.AreEqual(false, l1 == p1);
      Assert.AreEqual(false, l1 == p2);
      Assert.AreEqual(false, l2 == p1);
      Assert.AreEqual(false, l2 == p2);

     
     
    }




  }
}
