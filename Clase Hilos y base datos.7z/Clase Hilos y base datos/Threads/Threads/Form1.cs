﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;


namespace Threads
{
    public partial class Form1 : Form
    {
        int[] numeros;
        Thread t1;
        Thread t2;
      
        public Form1()
        {
            InitializeComponent();
            t1 = new Thread(new ParameterizedThreadStart(LanzarHilo));

            t2 = new Thread(new ParameterizedThreadStart(LanzarHilo));

          
            this.numeros = new int[4]{ 0, 0, 0, 0 };
        }
            
      

        public void LanzarHilo(object o)
        {
            int pos = (int)o;
            while (numeros[pos] < 10000)
            {
               
                numeros[pos]++;
                System.Threading.Thread.Sleep(30);
                Mostrar(numeros[pos], pos);
            }
        }

        public void Mostrar(int num, int pos)
        {
            switch (pos)
            {
                case 0:
                    if (this.textBox1.InvokeRequired)
                    {
                        this.textBox1.BeginInvoke((MethodInvoker)delegate
                        {
                            this.textBox1.Text = num.ToString();

                        });
                    }
                    else { this.textBox1.Text = num.ToString(); }
                    break;
                case 1:
                    if (this.textBox2.InvokeRequired)
                    {
                        this.textBox2.BeginInvoke((MethodInvoker)delegate
                        {
                            this.textBox2.Text = num.ToString();
                        });
                    }
                    else { this.textBox2.Text = num.ToString(); }
                    break;
                case 2:
                    if (this.textBox3.InvokeRequired)
                    {
                        this.textBox1.BeginInvoke((MethodInvoker)delegate
                        {
                            this.textBox3.Text = num.ToString();
                        });
                    }
                    else { this.textBox3.Text = num.ToString(); }
                    break;
                case 3:
                    if (this.textBox4.InvokeRequired)
                    {
                        this.textBox4.BeginInvoke((MethodInvoker)delegate
                        {
                            this.textBox4.Text = num.ToString();
                        });
                    }
                    else { this.textBox4.Text = num.ToString(); }
                    break;

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            t1.Start(0);
            t2.Start(1);
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            t1.Abort();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            t2.Abort();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
