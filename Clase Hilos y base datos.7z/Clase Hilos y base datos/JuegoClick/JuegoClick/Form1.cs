﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JuegoClick
{
    public partial class Form1 : Form
    {
        Thread thrTiempo;
        Thread thrMovimiento;
        static int tiempoPorDefecto;
        
        public Form1()
        {
            tiempoPorDefecto = 100;
            thrTiempo = new Thread(DescuentoTiempo);
            thrMovimiento = new Thread(MovimientoImagen);

            InitializeComponent();
        }

        private void MovimientoImagen()
        {
            if (this.pictureBox1.InvokeRequired)
            {
                this.pictureBox1.BeginInvoke((MethodInvoker)delegate
                {
                    if()
                });

            }
            Random rndTop = new Random();
            Random rndLeft = new Random();
            pictureBox1.Top = rndLeft.Next(0,740);
            pictureBox1.Left = rndTop.Next(30,200)
            
        }

        private void DescuentoTiempo()
        {
            
            for (int i = tiempoPorDefecto; i >= 0; i--)
            {
                txtTiempo.Text = i.ToString();
                Thread.Sleep(100);
            }
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            thrTiempo.Start();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
