using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimerProgramaWindowsForm
{
  public partial class FrmPantalla2 : Form
  {
    public string atributoString = "Atributo Clase FrmPantalla2 ";

    public FrmPantalla2()
    {
      InitializeComponent();
    }

    private void FrmPantalla2_Load(object sender, EventArgs e)
    {
      this.cmbPais.SelectedIndex = 0;
    }

    private void chkEnviaPublicidad_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void button1_Click(object sender, EventArgs e)
    {
      //MessageBox.Show(chkEnviaPublicidad.Checked.ToString());
      //MessageBox.Show(this.rdoArgentino.Checked ? "Argentino" : "extranjero");

      foreach (Control radio in grpNacionalidad.Controls)
      {
        if (radio is RadioButton && ((RadioButton)radio).Checked)
        {
          MessageBox.Show(radio.Text);
        }
      }
      string salida = "";
      foreach (object item in this.lstPosicion.SelectedItems)
      {
        salida += item.ToString() + " ";
      };
      MessageBox.Show(salida);
    }
    

    private void lstPosicion_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
  }
}
