namespace PrimerProgramaWindowsForm
{
    partial class FrmPantalla2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkEnviaPublicidad = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.grpNacionalidad = new System.Windows.Forms.GroupBox();
            this.rdoExtranjero = new System.Windows.Forms.RadioButton();
            this.rdoArgentino = new System.Windows.Forms.RadioButton();
            this.lstPosicion = new System.Windows.Forms.ListBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cmbPais = new System.Windows.Forms.ComboBox();
            this.grpNacionalidad.SuspendLayout();
            this.SuspendLayout();
            // 
            // chkEnviaPublicidad
            // 
            this.chkEnviaPublicidad.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkEnviaPublicidad.AutoSize = true;
            this.chkEnviaPublicidad.BackColor = System.Drawing.Color.Yellow;
            this.chkEnviaPublicidad.Checked = true;
            this.chkEnviaPublicidad.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.chkEnviaPublicidad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkEnviaPublicidad.Location = new System.Drawing.Point(38, 23);
            this.chkEnviaPublicidad.Name = "chkEnviaPublicidad";
            this.chkEnviaPublicidad.Size = new System.Drawing.Size(117, 17);
            this.chkEnviaPublicidad.TabIndex = 0;
            this.chkEnviaPublicidad.Text = "Queres publicicdad";
            this.chkEnviaPublicidad.UseVisualStyleBackColor = false;
            this.chkEnviaPublicidad.CheckedChanged += new System.EventHandler(this.chkEnviaPublicidad_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(33, 163);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 37);
            this.button1.TabIndex = 1;
            this.button1.Text = "Aceptar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // grpNacionalidad
            // 
            this.grpNacionalidad.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpNacionalidad.Controls.Add(this.rdoExtranjero);
            this.grpNacionalidad.Controls.Add(this.rdoArgentino);
            this.grpNacionalidad.Location = new System.Drawing.Point(38, 46);
            this.grpNacionalidad.Name = "grpNacionalidad";
            this.grpNacionalidad.Size = new System.Drawing.Size(247, 114);
            this.grpNacionalidad.TabIndex = 2;
            this.grpNacionalidad.TabStop = false;
            this.grpNacionalidad.Text = "Nacionalidad";
            // 
            // rdoExtranjero
            // 
            this.rdoExtranjero.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rdoExtranjero.AutoSize = true;
            this.rdoExtranjero.Location = new System.Drawing.Point(31, 63);
            this.rdoExtranjero.Name = "rdoExtranjero";
            this.rdoExtranjero.Size = new System.Drawing.Size(72, 17);
            this.rdoExtranjero.TabIndex = 1;
            this.rdoExtranjero.TabStop = true;
            this.rdoExtranjero.Text = "Extranjero";
            this.rdoExtranjero.UseVisualStyleBackColor = true;
            // 
            // rdoArgentino
            // 
            this.rdoArgentino.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rdoArgentino.AutoSize = true;
            this.rdoArgentino.Location = new System.Drawing.Point(31, 39);
            this.rdoArgentino.Name = "rdoArgentino";
            this.rdoArgentino.Size = new System.Drawing.Size(70, 17);
            this.rdoArgentino.TabIndex = 0;
            this.rdoArgentino.TabStop = true;
            this.rdoArgentino.Text = "Argentino";
            this.rdoArgentino.UseVisualStyleBackColor = true;
            // 
            // lstPosicion
            // 
            this.lstPosicion.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstPosicion.FormattingEnabled = true;
            this.lstPosicion.Items.AddRange(new object[] {
            "Primero",
            "Segundo",
            "Tercero",
            "Cuarto",
            "Quinto",
            "Sexto",
            "Septimo"});
            this.lstPosicion.Location = new System.Drawing.Point(266, 51);
            this.lstPosicion.Name = "lstPosicion";
            this.lstPosicion.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstPosicion.Size = new System.Drawing.Size(372, 121);
            this.lstPosicion.TabIndex = 3;
            this.lstPosicion.SelectedIndexChanged += new System.EventHandler(this.lstPosicion_SelectedIndexChanged);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(198, 187);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(33, 13);
            this.lblTitulo.TabIndex = 4;
            this.lblTitulo.Text = "Titulo";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(237, 178);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(175, 65);
            this.textBox1.TabIndex = 5;
            // 
            // cmbPais
            // 
            this.cmbPais.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPais.FormattingEnabled = true;
            this.cmbPais.Items.AddRange(new object[] {
            "Argentina\t",
            "Bolivia",
            "Brasil",
            "Chile",
            "Peru",
            "Paraguay",
            "Venezuela",
            "Uruguay",
            "Ecuador ",
            "Colombia"});
            this.cmbPais.Location = new System.Drawing.Point(454, 187);
            this.cmbPais.Name = "cmbPais";
            this.cmbPais.Size = new System.Drawing.Size(121, 21);
            this.cmbPais.TabIndex = 6;
            this.cmbPais.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // FrmPantalla2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 277);
            this.Controls.Add(this.cmbPais);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lstPosicion);
            this.Controls.Add(this.grpNacionalidad);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chkEnviaPublicidad);
            this.Name = "FrmPantalla2";
            this.Text = "frmPantalla2";
            this.Load += new System.EventHandler(this.FrmPantalla2_Load);
            this.grpNacionalidad.ResumeLayout(false);
            this.grpNacionalidad.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

    #endregion

    private System.Windows.Forms.CheckBox chkEnviaPublicidad;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.GroupBox grpNacionalidad;
    private System.Windows.Forms.RadioButton rdoExtranjero;
    private System.Windows.Forms.RadioButton rdoArgentino;
    private System.Windows.Forms.ListBox lstPosicion;
    private System.Windows.Forms.Label lblTitulo;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.ComboBox cmbPais;
  }
}
