using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;

namespace Ejercicio_57
{
  class Program
  {
    static void Main(string[] args)
    {
      Persona p1 = new Persona("Luciano", "Martinez");
      string path = "C:\\Users\\alumno\\Desktop\\Datos.txt.txt";
      try
      {
        Persona.Guardar(path, p1);
      }
      catch (FileNotFoundException e)
      {
        Console.WriteLine("Error el archivo no existe");
      }
      catch (IOException e)
      {
        Console.WriteLine($"Error E/S{e.Message}");
      }
      catch (SerializationException ex)
      {
        Console.WriteLine($"Error de serializacion{ex.Message}");
      }

      try
      {
        Persona p2 = new Persona();
        p2 = Persona.Leer("C:\\Users\\alumno\\Desktop\\Datos.txt.txt");
        Console.WriteLine(p2.ToString());
      }
      catch (FileNotFoundException e)
      {
        Console.WriteLine("Error el archivo no existe");
      }
      catch (IOException e)
      {
        Console.WriteLine($"Error E/S{e.Message}");
      }
      catch (SerializationException ex)
      {
        Console.WriteLine($"Error de serializacion{ex.Message}");
      }


      Console.ReadKey();
    }
  }
}
