using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_57
{
  [Serializable]
  public class Persona
  {
    private string nombre;
    private string apellido;

    public Persona() { }
    public Persona(string strNombre, string strApellido)
    {
      this.nombre = strNombre;
      this.apellido = strApellido;
    }
    public static bool Guardar(string path, Persona p)
    {
      try
      {
        //Objeto a serializar.
        FileStream fs;        //Objeto que escribirá en binario.
        BinaryFormatter ser;  //Objeto que serializará.

        fs = new FileStream(path, FileMode.Open);
        //Se indica ubicación del archivo binario y el modo.
        ser = new BinaryFormatter();
        //Se crea el objeto serializador.
        ser.Serialize(fs, p);
        //Serializa el objeto p en el archivo contenido en fs.
        fs.Close();
        //Se cierra el objeto fs.
      }
      catch (FileNotFoundException)
      {
        throw;
      }
      catch (IOException)
      {
        throw;
      }
      catch (SerializationException)
      {
        throw;
      }
      return true;

    }

    public static Persona Leer(string ruta)
    {
      Persona aux;   //Objeto que alojará los datos
                     //contenidos en el archivo binario.
      FileStream fs;                  //Objeto que leerá en binario.
      BinaryFormatter ser;      //Objeto que Deserializará.

      fs = new FileStream(ruta, FileMode.Open);
      //Se indica ubicación del archivo binario y el modo.
      ser = new BinaryFormatter();
      //Se crea el objeto deserializador.
      aux = (Persona)ser.Deserialize(fs);
      //Deserializa el archivo contenido en fs, lo guarda 
      //en aux.
      fs.Close();
      //Se cierra el objeto fs.
      return aux;
    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Nombre: " + this.nombre + " Apellido: " + this.apellido);
      return sb.ToString();
    }


  }
}
