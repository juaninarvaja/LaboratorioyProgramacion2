﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepasoClase5
{
    public class Producto
    {
        string codigoDeBarra;
        string marca;
        float precio;

        public Producto(string codigo, string marca, float precio)
        {
            this.codigoDeBarra = codigo;
            this.marca = marca;
            this.precio = precio;
        }
        public string GetMarca()
        {
            return this.marca;
        }
        public float GetPrecio()
        {
            return this.precio;
        }


        static public string MostrarProducto(Producto unProducto)
        {
            string cadena;
            if (unProducto is null)
            {
                return string.Empty;
            }
            else
            {
                cadena = string.Format("Codigo de barras: {0} \n Marca de Producto: {1} \n precio: {2} \n", unProducto.codigoDeBarra, unProducto.marca, unProducto.precio);
                return cadena;
            }
            
                
        }
        public static explicit operator string(Producto unProducto)
        {
            string retorno = unProducto.codigoDeBarra;
            return retorno;
        }

        public static bool operator ==(Producto producUno, Producto producDos)
            {
            if (!(producUno is null))
            {
                if (producUno.marca == producDos.marca && producUno.codigoDeBarra == producDos.codigoDeBarra)
                    return true;
                else
                    return false;
            }
            else
            {
                    return false;
            }
        }
           
        public static bool operator !=(Producto producUno, Producto producDos)
        {
            if (producUno.marca == producDos.marca && producUno.codigoDeBarra == producDos.codigoDeBarra)
                return false;
            else
                return true;
        }

        public static bool operator ==(Producto producUno, string marcaProducto)
        {
            if (producUno.marca == marcaProducto)
                return true;
            else
                return false;
        }

        public static bool operator !=(Producto producUno, string marcaProducto)
        {
            if (producUno.marca != marcaProducto)
                return true;
            else
                return false;
        }
    }


}
