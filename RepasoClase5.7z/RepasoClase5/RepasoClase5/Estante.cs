﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepasoClase5
{
    class Estante
    {
        private int ubicacionEstante;
        private Producto[] productos;

        private Estante(int capacidad)
        {
            productos = new Producto[capacidad];
        }
        public Estante(int capacidad, int ubicacion) : this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }
        public Producto[] GetProducto()
        {
            return this.productos;
        }
        static public string MostrarEstante(Estante unEstante)
        {
            string cadena = string.Format("Nº de estante: {0}, Capacidad del estante: {1} \n", unEstante.ubicacionEstante, unEstante.productos.Length);
            int i;
            for (i = 0; i < unEstante.GetProducto().Length; i++)
            {
                cadena += Producto.MostrarProducto(unEstante.GetProducto()[i]);
            }
            return cadena;
        }
        public static bool operator ==(Estante unEstante, Producto unProducto)
        {
            bool retorno = false;
            for (int i = 0; i < unEstante.GetProducto().Length; i++)
            {
                if (unEstante.GetProducto()[i] == unProducto)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }
        public static bool operator !=(Estante unEstante, Producto unProducto)
        {
            bool retorno = true;
            for (int i = 0; i < unEstante.GetProducto().Length; i++)
            {
                if (unEstante.GetProducto()[i] == unProducto)
                {
                    retorno = false;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator +(Estante unEstante, Producto unProducto)
        {
            bool retorno = false;
            if (unEstante != unProducto)
            {
                for (int i = 0; i < unEstante.GetProducto().Length; i++)
                {
                    if (unEstante.GetProducto()[i] is null)
                    {
                        unEstante.GetProducto()[i] = unProducto;
                        retorno = true;
                        break;
                    }
                }
            }
            return retorno;
        }

        public static bool operator -(Estante unEstante, Producto unProducto)
        {
            bool retorno = false;
            if (unEstante == unProducto)
            {
                for (int i = 0; i < unEstante.GetProducto().Length; i++)
                {
                    if (unEstante.GetProducto()[i] == unProducto)
                    {
                        unEstante.GetProducto()[i] = null;
                        retorno = true;
                        break;
                    }
                }
            }
            return retorno;
        }

    }
}

