using Excepciones;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;



namespace Entidades
{
  public class SerializarXML<T> : IArchivos<T>
  {
    string contenido;
    public string Contenido
    {
      get { return this.contenido; }
      set { this.contenido = value; }

    }

    public bool Guardar(string ruta, T obj)
    {
      bool guardo = true;
      object p = new object();   //Objeto a serializar.
      XmlTextWriter writer = null;  //Objeto que escribirá en XML.
      XmlSerializer ser;        //Objeto que serializará.

      if (Path.GetExtension(ruta) == ".xml")
      {
        try
        {
          writer = new XmlTextWriter(ruta, Encoding.ASCII);
          //Se indica ubicación del archivo XML y su codificación.
          ser = new XmlSerializer(typeof(T));
          //Se indica el tipo de objeto ha serializar.
          ser.Serialize(writer, p);
          //Serializa el objeto p en el archivo contenido en writer


        }
        catch (Exception e)
        {
          guardo = false;
          throw new ErrorArchivoExcepcion("Error al Guardar", e);
        }
        finally
        {
          if (writer != null)
          {
            writer.Close();
          } 
        }
      } 

      return guardo;     
      //Se cierra el objeto writer.
    }


    public T Leer(string ruta)
    {
       object aux = null;   //Objeto que alojará los datos
      XmlTextReader reader = null ;   //Objeto que leerá XML.
      XmlSerializer ser;            //Objeto que Deserializará.

      if (Path.GetExtension(ruta) == ".xml")
      {
        try
        {
          //contenidos en el archivo XML.


          reader = new XmlTextReader(ruta);
          //Se indica ubicación del archivo XML.
          ser = new XmlSerializer(typeof(T));
          //Se indica el tipo de objeto ha serializar.
          aux = (T)ser.Deserialize(reader);
          //Deserializa el archivo contenido en reader, lo guarda 
          //en aux.

          //Se cierra el objeto reader.

        }
        catch (Exception e)
        {
          throw new ErrorArchivoExcepcion("error al leer",e);
        }
        finally
        {
          if (reader != null)
          {
            reader.Close();
          } 
        }
        
      }
      return (T)aux;

    }

    #region XML




    public bool ValidarArchivo(string ruta)
    {
      if (Path.GetExtension(ruta) != ".dat")
      {
        //ArchivoIncorrectoExcepcion e = new ArchivoIncorrectoExcepcion(); //("Error, Extension incorrecta, no es TXT", );
        //throw new ArchivoIncorrectoExcepcion("Extension incorrecta, no es DAT");
        return false;
      }
      return true;
    }


    #endregion
 
      }
    }
