using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class DAO : IArchivos<Votacion>
  {
    private static string StrConnection;
    private static SqlConnection Con;
      
    static DAO()
    {
      StrConnection = "Data Source=.\\SQLEXPRESS;Initial Catalog=votacion-sp-2018;Integrated Security=True";
      
      Con = new SqlConnection(StrConnection);
    }


    public bool Guardar(string ruta, Votacion objeto)
    {
      bool guardado = false;
      string query = string.Format("insert into dbo.Votaciones(nombreLey,afirmativos,negativos,abstenciones,nombreAlumno) values ('{0}',{1},{2},{3},'NarvajaJuan')",
        objeto.Nombreley, objeto.ContadorNegativo, objeto.ContadorAfirmativo, objeto.ContadorAbstencion);
      SqlCommand command = new SqlCommand(query, Con);

      try
      {
        Con.Open();
        if (command.ExecuteNonQuery() > 0)
        {
          guardado = true;
        }
      }
      catch(Exception e )
      {
        throw e;
      }
      finally
      {
        if (Con.State != System.Data.ConnectionState.Closed)
        {
          Con.Close();
        }
      }
      return guardado;
    }

    public Votacion Leer(string ruta)
    {
      throw new NotImplementedException();
    }
  }
}
