using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public abstract class Vehiculos
  {
    protected DateTime fecha;
    private string patente;


    public string Patente
    {
      get{ return this.patente; }
      set{
        if (patente.Length == 6)
        {
          this.patente = value;
        }
        else this.patente = null;
        
      }

    }

    public Vehiculos(string patente)
    {
      this.patente = patente;
      fecha = DateTime.Now.AddHours(-3);
    }


    public abstract string ConsultarDatos();

    /// <summary>
    /// Devuelve un String con la patente y su numero
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendFormat("Patente {0}", this.patente);
      return sb.ToString();
    }

    /// <summary>
    /// Devuelve un string con los datos del vehiculo
    /// </summary>
    /// <returns></returns>
    public virtual string ImprimirTicket()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendFormat(this.ToString());
      sb.AppendFormat(this.fecha.Date.ToString() + this.fecha.Hour.ToString());
      return sb.ToString();

    }
    /// <summary>
    /// Compara si dos vehiculos son iguales
    /// </summary>
    /// <param name="a">primer vehiculo</param>
    /// <param name="b">segundo vehiculo</param>
    /// <returns>retorna true si son iguales, false en caso contrario</returns>
    public static bool operator ==(Vehiculos a, Vehiculos b)
    {
      bool esIgual = false;
      if (a.Patente == b.Patente)
      {
        esIgual = true;
      }
      return esIgual;
    }

    /// <summary>
    /// Compara Si dos vehiculos son diferentes
    /// </summary>
    /// <param name="a">primer Vechiulo</param>
    /// <param name="b">Segundo vehiculo</param>
    /// <returns>false si son iguales, treue si son distintos</returns>
    public static bool operator !=(Vehiculos a, Vehiculos b)
    {
      return !(a == b);
    }



    //ImprimirTicket podrá ser anulado en las clases derivadas.Utilizará StringBuilder para retornar los
    //datos del Vehiculo (reutilizar ToString) y la fecha y hora de ingreso
  }
}
