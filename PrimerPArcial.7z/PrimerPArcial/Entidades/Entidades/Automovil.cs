using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{

  public class Automovil : Vehiculos
  {
    private ConsoleColor color;
    private static int valorHora;

    static Automovil()
    {
      valorHora = 50;
    }
    public Automovil(string patente, ConsoleColor color) : base(patente)
    {
      this.Patente = patente;
      this.color = color;
    }
    public Automovil(string patente, ConsoleColor color, int valorHs) : base(patente)
    {
      this.Patente = patente;
      this.color = color;
      valorHora = valorHs;
    }
    public override bool Equals(Object m)
    {
      if (m is Automovil)
      {
        return true;
      }
      else return false;
    }
    /// <summary>
    /// Devuelve un string con los datos del vehiculo y del Auto
    /// </summary>
    /// <returns></returns>
    public override string ConsultarDatos()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Vehiculo: Automovil");
      sb.AppendLine("Patente: " + this.Patente);
      sb.AppendLine("Color " + this.color);
      sb.AppendLine("Valor Hora" + valorHora);

      return sb.ToString();
    }
    /// <summary>
    /// Devuellve un String con los datos y el precio a pagar
    /// </summary>
    /// <returns></returns>
    public override string ImprimirTicket()
    {
      double valorEstadia;
      var fechaEntrada = base.fecha;
      var timeSpan = DateTime.Now - fechaEntrada;
      double cantidadHoras = timeSpan.TotalHours;
      valorEstadia = cantidadHoras * valorHora;

      StringBuilder sb = new StringBuilder();
      sb.AppendFormat(this.ConsultarDatos());
      sb.AppendFormat("Costo Estadia : " + Math.Round(valorEstadia, 2).ToString());
      return sb.ToString();
    }


  }
}
