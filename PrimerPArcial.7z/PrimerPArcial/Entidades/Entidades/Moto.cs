using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Moto : Vehiculos
  {
    private int cilindrada;
    private  short ruedas;
    private static int valorHora;

    static Moto()
    {
      valorHora = 30;
    }

    public Moto(string patente, int cilindrada) : base(patente) 
    {
      this.Patente = patente;
      this.cilindrada = cilindrada;
      this.ruedas = 2;
      

    }
    public Moto(string patente, int cilindrada, short ruedas) : base(patente)
    {
      this.Patente = patente;
      this.cilindrada = cilindrada;
      this.ruedas = ruedas;
      

    }
    public Moto(string patente, int cilindrada, short ruedas, int valorHs) : base(patente)
    {
      this.Patente = patente;
      this.cilindrada = cilindrada;
      this.ruedas = ruedas;
      valorHora = valorHs;

    }
    /// <summary>
    /// Devuelve un string con los datos del vehiculo y de la Moto
    /// </summary>
    /// <returns></returns>
    public override string ConsultarDatos()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Vehiculo: Moto");
      sb.AppendLine("Patente: "+this.Patente);
      sb.AppendLine("cantidad Ruedas: " + this.ruedas);
      sb.AppendLine("Valor Hora" +valorHora);

      return sb.ToString();
    }

    /// <summary>
    /// Devuellve un String con los datos y el precio a pagar
    /// </summary>
    /// <returns></returns>
    public override string ImprimirTicket()
    {
      double valorEstadia;
      var fechaEntrada = base.fecha;
      var timeSpan = DateTime.Now - fechaEntrada;
      double cantidadHoras = timeSpan.TotalHours;
      valorEstadia = cantidadHoras * valorHora;

      StringBuilder sb = new StringBuilder();
      sb.AppendLine(this.ConsultarDatos());
      sb.AppendFormat("Costo Estadia : " + Math.Round(valorEstadia, 2).ToString());
      return sb.ToString();
    }

    public override bool Equals(Object m)
    {
      if (m is Moto)
      {
        return true;
      }
      else return false;
    }


  }
}
