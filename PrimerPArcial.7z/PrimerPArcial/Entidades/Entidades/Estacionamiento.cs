using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Estacionamiento
  {
    private int espacioDisponible;
    private string nombre;
    private List<Vehiculos> vehiculos;

    private Estacionamiento()
    {
      this.vehiculos = new List<Vehiculos>();
    }
    public Estacionamiento(string nombre, int espacio) : this()
    {
      this.espacioDisponible = espacio;
      this.nombre = nombre;
    }
    public static explicit operator string(Estacionamiento e)
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Nombre Estacionamiento: " + e.nombre);
      sb.AppendLine("Espacio Disponible : " + e.espacioDisponible);
      foreach (Vehiculos v in e.vehiculos)
      {
        if(v.Patente != null)
        sb.AppendLine("Vehiculo :" + v.ConsultarDatos());
        sb.AppendLine("---------- ");
        

      }
      return sb.ToString();

    }

    /// <summary>
    /// Mira si existe este vehiculo en dicho estacionamiento
    /// </summary>
    /// <param name="e"> Estacionamiento</param>
    /// <param name="v"> Vehiculo </param>
    /// <returns> true si existe, en caso contrario fasle</returns>
    public static bool operator ==(Estacionamiento e, Vehiculos v)
    {
      // Si encuentro al empleado en la nómina, salgo del método.
      foreach (Vehiculos vehiculosDentro in e.vehiculos)
      {
        if (vehiculosDentro.Patente == v.Patente)
        {
          return true;
        }
      }
      return false;
    }

    /// <summary>
    /// Mira si no existe este vehiculo en dicho estacionamiento
    /// </summary>
    /// <param name="e"> Estacionamiento</param>
    /// <param name="v"> Vehiculo </param>
    /// <returns> false si existe, en caso contrario true</returns>
    public static bool operator !=(Estacionamiento e, Vehiculos v)
    {
      return !(e == v);
    }


    /// <summary>
    /// Agrega un vehiculo a un estacionamiento, luego de algunas validaciones
    /// </summary>
    /// <param name="e"> estacionamiento</param>
    /// <param name="v">vehiculo</param>
    /// <returns> retorna el estacionamiento</returns>
    public static Estacionamiento operator +(Estacionamiento e, Vehiculos v)
    {
      if (e != v && v.Patente != null && e.espacioDisponible > e.vehiculos.Count)
      {
        e.vehiculos.Add(v);
      }
      return e;
    }

    /// <summary>
    /// Saco un vehiculo a un estacionamiento y imprimo su tiCket
    /// </summary>
    /// <param name="e"> estacionamiento</param>
    /// <param name="v">vehiculo</param>
    /// <returns> retorna el estacionamiento</returns>
    public static Estacionamiento operator -(Estacionamiento e, Vehiculos v)
    {
      Console.WriteLine(v.ImprimirTicket());
      
      e.vehiculos.Remove(v);
      return e;
    }




  }


}
