using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public  class PickUp : Vehiculos
  {
    private string modelo;
    private static int valorHora;
    static PickUp()
    {
      valorHora = 70;
    }
    public PickUp(string patente, string modelo) : base(patente)
    {
      this.Patente = patente;
      this.modelo = modelo;
    }
    public PickUp(string patente, string modelo, int valorHs) : base(patente)
    {
      this.Patente = patente;
      this.modelo = modelo;
      valorHora = valorHs;
    }
    public override bool Equals(Object m)
    {
      if (m is PickUp)
      {
        return true;
      }
      else return false;
    }


    /// <summary>
    /// Devuelve un string con los datos del vehiculo y de la PickUP
    /// </summary>
    /// <returns></returns>

    public override string ConsultarDatos()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Vehiculo: PickUp");
      sb.AppendLine("Patente: " + this.Patente);
      sb.AppendLine("Mdelo " + this.modelo);
      sb.AppendLine("Valor Hora" + valorHora);

      return sb.ToString();
    }
    /// <summary>
    /// DEvueklve un String con los datos y el precio a pagar
    /// </summary>
    /// <returns></returns>
    public override string ImprimirTicket()
    {
      double valorEstadia;
      var fechaEntrada = base.fecha;
      var timeSpan = DateTime.Now - fechaEntrada;
      double cantidadHoras = timeSpan.TotalHours;
      valorEstadia = cantidadHoras * valorHora;

      StringBuilder sb = new StringBuilder();
      sb.AppendFormat(this.ConsultarDatos());
      sb.AppendFormat("Costo Estadia : " + Math.Round(valorEstadia,2).ToString());
      return sb.ToString();
    }


  }
}
