﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio_47
{
    public class EquipoBasquet : Equipo
    {
        public EquipoBasquet(string nombre, DateTime fecha ): base(nombre, fecha){ }


}
}
