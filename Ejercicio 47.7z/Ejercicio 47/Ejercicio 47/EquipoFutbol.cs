﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio_47
{
    public class EquipoFutbol : Equipo
    {
        public EquipoFutbol(string nombre ,DateTime fecha ): base(nombre,fecha){ }
    }
}
