﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio_47
{
    public class Torneo<T> : IEnumerable where T : Equipo
    {
        string nombre;
        List<T> lista;

        public Torneo(string name)
        {
            this.nombre = name;
            lista = new List<T>();
        }

        public IEnumerator GetEnumerator()
        {
            for (int i = 0; i < this.lista.Count; i++)
            {
                yield return this.lista[i];
            }
        }

        #region metodos

        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Nombre del Torneo: " + this.nombre);
            foreach (T team in this.lista)
            {
               
                sb.AppendLine(team.Ficha());
            }
            return sb.ToString();
        }
        private string calcularPartido(T team, T team2)
        {
            StringBuilder sb = new StringBuilder();
            Random rdm = new Random();
            int r1 = rdm.Next(30);
            int r2 = rdm.Next(30);
            sb.AppendLine(team.Nombre() + r1 + "-" + r2 + team2.Nombre());
            return sb.ToString();

        }
        #endregion

        #region Operadores
        static public bool operator ==(Torneo<T> t, T e)
        {
            bool yaEsta = false;
            foreach (Equipo equipo in t.lista)
            {
                if (equipo.Equals(e))
                {
                    yaEsta = true;
                }
            }
            return yaEsta;
        }

        static public bool operator !=(Torneo<T> t, T e)
        {

            return !(t == e);
        }

        static public Torneo<T> operator +(Torneo<T> t, T e)
        {
            
            if (t != e)
            {
                t.lista.Add(e);
                

            }
            return t;
        }

        #endregion
        #region propiedades
        public string JugarPartido
        {
            get
            {
                Random rdm = new Random();
                int r1 = rdm.Next(this.lista.Count);
                int r2 = rdm.Next(this.lista.Count);
                string str = this.calcularPartido(lista[r1], lista[r2]);

                return str;

            }
            }


            #endregion



        }
    }

