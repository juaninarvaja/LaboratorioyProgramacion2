﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio_47
{
    public  abstract class Equipo
    {
        DateTime fechaCreacion;
        string nombre;

        public Equipo(string strNombre, DateTime fechaCrea)
        {
            this.nombre = strNombre;
            this.fechaCreacion = fechaCrea;
        }


        #region operadores
        public static bool operator ==(Equipo e1, Equipo e2)
        {
            bool sonIguales = false;
            if (e1.nombre == e2.nombre && e1.fechaCreacion == e2.fechaCreacion)
            {
                sonIguales = true;
            }
            return sonIguales;

        }

        public static bool operator !=(Equipo e1, Equipo e2)
        {
            return !(e1 == e2);
        }

        #endregion 

        public string Ficha()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Club : " + this.nombre + "   Fundado el :" + fechaCreacion);
            return sb.ToString();

        }
        public string Nombre()
        {

            return this.nombre;

        }

    }
}
