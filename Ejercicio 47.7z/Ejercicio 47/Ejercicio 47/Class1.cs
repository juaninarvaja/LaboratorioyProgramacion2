﻿using System;

namespace Ejercicio_47
{
    public class Class1
    {
    }
}
