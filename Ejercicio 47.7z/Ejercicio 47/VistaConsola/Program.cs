﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_47;

namespace VistaConsola
{
    class Program
    {
        static void Main(string[] args)
        {
            Torneo<EquipoFutbol> torneoFutbol = new Torneo<EquipoFutbol>("SuperLiga");
            Torneo<EquipoBasquet> torneoBasquet = new Torneo<EquipoBasquet>("Campeonato de Basquet");
            EquipoBasquet eBasquet1 = new EquipoBasquet("Quilmes Basquet",DateTime.Now);
            EquipoBasquet eBasquet2 = new EquipoBasquet("Obras Basquet",DateTime.Now);
            EquipoBasquet eBasquet3 = new EquipoBasquet("Wendy Basquet",DateTime.Now);

            EquipoFutbol eFutbol1 = new EquipoFutbol("Boca Juniors", DateTime.Now);
            EquipoFutbol eFutbol2 = new EquipoFutbol("Chaira", DateTime.Now);
            EquipoFutbol eFutbol3 = new EquipoFutbol("Racing Club Olavarria", DateTime.Now);

            torneoFutbol += eFutbol1;
            torneoFutbol += eFutbol2;
            torneoFutbol += eFutbol3;

            torneoBasquet += eBasquet1;
            torneoBasquet += eBasquet2;
            torneoBasquet += eBasquet3;

            string torneoFutbolDatos = torneoFutbol.Mostrar();
            Console.WriteLine(torneoFutbolDatos);
            Console.ReadKey();
            string torneoBasquetDatos = torneoBasquet.Mostrar();
            Console.WriteLine(torneoBasquetDatos);
            Console.ReadKey();

             Console.WriteLine(torneoFutbol.JugarPartido);
            Console.ReadKey();
            Console.WriteLine(torneoBasquet.JugarPartido);
            Console.ReadKey();

        }
    }
}
