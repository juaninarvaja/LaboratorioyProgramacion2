using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IO_Ejericio58
{
    public class ArchivoIncorrectoExcepcion : Exception
    {
        public ArchivoIncorrectoExcepcion()
        {
        }

        public ArchivoIncorrectoExcepcion(string message, Exception innerException)
        : base(message, innerException)
        {

        }
    public ArchivoIncorrectoExcepcion(string message)
     : base(message)
    {

    }

  }
}
