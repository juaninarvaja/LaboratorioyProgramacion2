using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace IO_Ejericio58
{
  [Serializable]
  public class PuntoDat : Archivo, IArchivos<PuntoDat>
  {
    private string contenido;
    public string Contenido
    {
      get { return this.contenido; }
      set { this.contenido = value; }

    }



    public bool Guardar(string ruta, PuntoDat obj)
    {
        //Objeto a serializar.
        FileStream fs;        //Objeto que escribirá en binario.
        BinaryFormatter ser;  //Objeto que serializará.

        fs = new FileStream(ruta, FileMode.Create);
        //Se indica ubicación del archivo binario y el modo.
        ser = new BinaryFormatter();
        //Se crea el objeto serializador.
        ser.Serialize(fs, obj);
        //Serializa el objeto p en el archivo contenido en fs.
        fs.Close();
        //Se cierra el objeto fs.
        return true;
  
    }

    public PuntoDat Leer(string ruta)
    {
      if (ValidarArchivo(ruta))
      {
        PuntoDat aux;   //Objeto que alojará los datos
                        //contenidos en el archivo binario.
        FileStream fs;                  //Objeto que leerá en binario.
        BinaryFormatter ser;      //Objeto que Deserializará.

        fs = new FileStream(ruta, FileMode.Open);
        //Se indica ubicación del archivo binario y el modo.
        ser = new BinaryFormatter();
        //Se crea el objeto deserializador.
        aux = (PuntoDat)ser.Deserialize(fs);
        //aux.contenido = (string)ser.Deserialize(fs);
        this.contenido = aux.Contenido;

        //Deserializa el archivo contenido en fs, lo guarda 
        //en aux.
        fs.Close();
        //Se cierra el objeto fs.
        return aux;
      }
      else
        return null;


    }


    public override bool ValidarArchivo(string ruta)
    {
      if (base.ValidarArchivo(ruta))
      {
        if (Path.GetExtension(ruta) != ".dat")
        {
          //ArchivoIncorrectoExcepcion e = new ArchivoIncorrectoExcepcion(); //("Error, Extension incorrecta, no es TXT", );
          throw new ArchivoIncorrectoExcepcion("Extension incorrecta, no es DAT");
        }

      }
      return true;
    }
  }
}

