using System;
using Clases;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    [ExpectedException(typeof(CantidadInvalidaException))]
    public void TestMethod1()
    {
      Tren tren = new Tren();
      tren += -1;
    }
  }
}
