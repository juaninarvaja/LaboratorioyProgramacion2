﻿using System;
using Clases;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Test
{
    public class UnitTest1
    {
        
    }
}
