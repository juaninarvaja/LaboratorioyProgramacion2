using Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NarvajaJuan
{
  public partial class Form1 : Form
  {
    Tren trenes;
   
    public Form1()
    {
      InitializeComponent();
      trenes = new Tren();
    }

    private void btnArrancarTren_Click(object sender, EventArgs e)
    {

      try
      {
        trenes = trenes + (int)numericUpDown1.Value;
      }
      catch (CantidadInvalidaException)
      {
        MessageBox.Show("Error al agregar trenes");
      }
    }

    private void InformarArribo(string mensaje)
    {
      MessageBox.Show(mensaje);
    }

    private void btnArribos_Click(object sender, EventArgs e)
    {
      MessageBox.Show(trenes.Registros);
    }
  }
}
