﻿namespace NarvajaJuan
{
  partial class Form1
  {
    /// <summary>
    /// Variable del diseñador necesaria.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Limpiar los recursos que se estén usando.
    /// </summary>
    /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Código generado por el Diseñador de Windows Forms

    /// <summary>
    /// Método necesario para admitir el Diseñador. No se puede modificar
    /// el contenido de este método con el editor de código.
    /// </summary>
    private void InitializeComponent()
    {
            this.btnArrancarTren = new System.Windows.Forms.Button();
            this.btnArribos = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnArrancarTren
            // 
            this.btnArrancarTren.Location = new System.Drawing.Point(28, 22);
            this.btnArrancarTren.Name = "btnArrancarTren";
            this.btnArrancarTren.Size = new System.Drawing.Size(565, 185);
            this.btnArrancarTren.TabIndex = 0;
            this.btnArrancarTren.Text = "Arrancar Tren";
            this.btnArrancarTren.UseVisualStyleBackColor = true;
            this.btnArrancarTren.Click += new System.EventHandler(this.btnArrancarTren_Click);
            // 
            // btnArribos
            // 
            this.btnArribos.Location = new System.Drawing.Point(193, 213);
            this.btnArribos.Name = "btnArribos";
            this.btnArribos.Size = new System.Drawing.Size(400, 55);
            this.btnArribos.TabIndex = 1;
            this.btnArribos.Text = "Arribos";
            this.btnArribos.UseVisualStyleBackColor = true;
            this.btnArribos.Click += new System.EventHandler(this.btnArribos_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(51, 232);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(91, 20);
            this.numericUpDown1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(605, 280);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.btnArribos);
            this.Controls.Add(this.btnArrancarTren);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button btnArrancarTren;
    private System.Windows.Forms.Button btnArribos;
    private System.Windows.Forms.NumericUpDown numericUpDown1;
  }
}

