using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
  public static class Extension
  {
    /// <summary>
    /// extension de tren para poder verlos
    /// </summary>
    /// <param name="tren">tren que quiero ver</param>
    /// <returns></returns>
    public static string VerTren(this Tren tren)
    {
      string aux = tren.Registros;
      return aux;

    }
  }
}
