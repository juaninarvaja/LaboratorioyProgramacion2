using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{





  //o Arribar (Implementación IArribo ) hará los siguientes pasos, en el siguiente orden:
  //. Creará un mensaje con el siguiente formato: "Llegó el tren {0}.".
  //i.Guardará el mensaje en la property Registros.
  //ii.Ejecutará el evento EventoArribo.
  // El operador + lanzará la excepción CantidadInvalidaException en el caso de que la cantidad sea
  //menor a 1. Si cantidad es mayor a 0, deberá agregar tantos trenes como indique dicha cantidad.
  public class Tren : IArribo<int>
  {
    private static int contadorTrenes;
    private int id;
    private List<ManejadorTrenes> manejadorTrenes;
    private static string path;

    #region constructrores
    /// <summary>
    /// constructor statico
    /// </summary>
    static Tren()
    {
      contadorTrenes = 0;
      path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
      path += @"\" + "RegistroDeTrenes.txt";
    }
    /// <summary>
    /// constructor publico de isntancia
    /// </summary>
    public Tren()
    {
      this.id = contadorTrenes;
      contadorTrenes++;
      manejadorTrenes = new List<ManejadorTrenes>();
    }
    #endregion
    #region propiedades
    /// <summary>
    /// Devuelve el manejadotr de trenes
    /// </summary>
    List<ManejadorTrenes> ManejadorTrenes
      {
      get { return this.manejadorTrenes; }
     
      }
    /// <summary>
    /// Devuelve o recibe datos para el archivo tanto para basde de datos como para txt
    /// </summary>
    public string Registros
    {
      get
      {
        string msj = "";
        Archivos.Leer(path, out msj);
        return msj;
      }
      set
      {
        string aux = "arribo el tren " + this.id;
        Archivos.GuardarArribo(path, aux);
        Datos.GuardarArribo(this.id, DateTime.Now, aux);
      }
    }

    #endregion
    // Evento
    public event MyDelegate EventoArribo;

    // Delegado
    public delegate void MyDelegate(string s);

    /// <summary>
    /// agrega trenes
    /// </summary>
    /// <returns></returns>
    private Tren AgregarTren()
    {
      Tren tr = new Tren();
      tr.EventoArribo = this.EventoArribo;
      ManejadorTrenes mj = new ManejadorTrenes(this.id, tr);
      return tr;
    }
    public void Arribar(int id)
    {
      string aux = string.Format("llego el tren {0}", this.id);
      this.Registros = aux;
      //EventoArribo.Invoke; //ver
    }

    public static Tren operator +(Tren tr, int cantidad)
    {
      if (cantidad < 1)
      {
        throw new CantidadInvalidaException();
      }
      else
      {
        for (int i = 0; i < cantidad; i++)
        {
          tr.AgregarTren();
        }
        return tr;
      }

    }

  }
}
