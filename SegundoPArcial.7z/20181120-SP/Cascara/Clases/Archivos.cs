using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
//   Atributos:
//o streamreader(static StreamReader).
//o streamWriter(static StreamWriter).
// Métodos:
//o Leer:
// Recibe el path de un archive, lo lee complete y carga un parámetro de tipo
//string que recibe por referencia(out) con el contenido.
// Retorna un booleano que indica el éxito de la operación.
//o Guardar:
// Recibe el path de un archive, lo lee complete y agrega el mensaje que recibe
//como parámetro al final del archivo.
// Retorna un booleano que indica el éxito de la operación.
// Constructor:
//o Estático sin parámetros, le asigna el valor al connectionString
  public static class Archivos
  {
    static StreamReader streamReader;
    static StreamWriter streamWriter;

    /// <summary>
    /// Lee el archivo y devuele bool si pudo y en el string de salida los datos
    /// </summary>
    /// <param name="path">direccion del mismo</param>
    /// <param name="mensaje">devuelve los datos</param>
    /// <returns></returns>
    public static bool Leer(string path, out string mensaje)
    {

      try
      {
        streamReader = File.OpenText(path);
        mensaje = streamReader.ReadToEnd();
        streamReader.Close();
        return true;
      }
      catch
      {
       mensaje = string.Empty;
        return false;
      }
    }
    /// <summary>
    /// Guarda los arribos en eel txt
    /// </summary>
    /// <param name="path">direccion del archivo </param>
    /// <param name="mensaje">mensaje a guardar</param>
    /// <returns></returns>
    public static bool GuardarArribo(string path,string mensaje)
    {
      bool guardado = false;
  
      try
      {
        streamWriter = File.CreateText(path);
        streamWriter.Write(mensaje);
      }
      catch
      {
        guardado = false;
      }
      finally
      {
        streamWriter.Close();
      }

      return guardado;

    }

  }
}
