using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
//  Clase estática Dato
// Atributos:
//o connectionString(static string), debe contener la información necesaria para
//conectarse a la base de datos.
// Métodos:
//o GuardarArribo, guarda los parámetros que recibe en la tabla trenes.
// Constructor:
//o Estático sin parámetros, le asigna el valor al connectionString.
  public static class Datos
  {
    static string ConnectionString;

    /// <summary>
    /// constructor estatico de instancia
    /// </summary>
    static Datos()
    {
      ConnectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=parcial;Integrated Security=True";
    }
    /// <summary>
    /// guarda los arribos en base de datos
    /// </summary>
    /// <param name="id">id a guardar</param>
    /// <param name="arribo">fecha dt</param>
    /// <param name="mensaje">mensaje a guardar</param>
    public static void GuardarArribo(int id, DateTime arribo, string mensaje)
    {

      string query = string.Format("insert into dbo.trenes values('{0}', '{1}', '{2}')",
          id,arribo,mensaje);
    SqlConnection Con;
     Con = new SqlConnection(ConnectionString);
     SqlCommand command = new SqlCommand(query, Con);

      try
      {
        Con.Open();
      }
      catch(Exception e)
      {
        throw new Exception("error",e);
      }
      finally
      {
        if (Con.State != System.Data.ConnectionState.Closed)
          Con.Close();
      }

    
    }
  }
}
