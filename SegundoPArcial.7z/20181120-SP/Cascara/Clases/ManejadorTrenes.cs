using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Clases
{
//  Constructores:
//o Dos parámetros: recibe un id(int) y el callback(IArribo<int>).
//i.Deberá instanciar el atributo Hilo pasándole el método Ejecutar.
//ii.Iniciará al atributo Hilo.
// Atributo:
//o random (static random). El mismo se inicializará en un constructor de clase.
//o hilo(Thread) será el que ejecutará el método Ejecutar.
// Métodos:
//o Ejecutar frenará el código durante un tiempo aleatorio de entre 1 y 5 segundos.Luego
//de transcurrir este tiempo, utilizará el método Arribar del callback pasando como
//parámetro el atributo id.
  public class ManejadorTrenes
  { 
    private IArribo<int> callback;
    private Thread hilo;
    private int id;
    private Random random;

    /// <summary>
    /// constructotr publico de instancia
    /// </summary>
    public ManejadorTrenes()
    {
     this.random = new Random();
     
    }
    /// <summary>
    /// constructor qeu recibe parametros publico
    /// </summary>
    /// <param name="id">id</param>
    /// <param name="callback">cb</param>
    public ManejadorTrenes(int id, IArribo<int> callback) : this()
    {
      this.id = id;
      this.callback = callback;
      hilo = new Thread(Ejecutar);
      hilo.Start();
    }

    /// <summary>
    /// Ejecuta los arribos con un sleep de por medio
    /// </summary>
    private void Ejecutar()
    {
      int aux = this.random.Next(1000,5000);
      Thread.Sleep(aux);
      callback.Arribar(id);

    }
  }
}
