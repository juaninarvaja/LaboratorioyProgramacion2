﻿using Clases;
using System;
using System.Windows.Forms;

namespace PreParcialLabo_II
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnArrancarTren_Click(object sender, EventArgs e)
        {            
        }

        private void btnArribos_Click(object sender, EventArgs e)
        {
        }
    }
}
