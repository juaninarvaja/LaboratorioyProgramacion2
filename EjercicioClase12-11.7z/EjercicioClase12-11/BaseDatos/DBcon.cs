﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BaseDatos
{
    public class DBcon
    {
    private static string strConexion;

    public DBcon()
    {
        strConexion = "Data Source=[SQLEXPRESS];Initial Catalog=[dbEjercicio];Integrated Security=True";

    }
    public static string StrConexion
    {
        get { return strConexion; }
    }
}
}
