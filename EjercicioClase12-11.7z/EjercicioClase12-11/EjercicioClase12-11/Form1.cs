﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioClase12_11
{
    public partial class Form1 : Form
    {
        Thread t1;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            FormCargarAlumno form1 = new FormCargarAlumno();
            form1.ShowDialog(this);
        }

        private void BtnModificar_Click(object sender, EventArgs e)
        {

        }
    }
}
