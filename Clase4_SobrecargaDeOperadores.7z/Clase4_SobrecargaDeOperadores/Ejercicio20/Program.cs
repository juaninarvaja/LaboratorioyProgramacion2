﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio20
{
    class Program
    {
        static void Main(string[] args)
        {
            Pesos nuevoPeso = new Pesos(100);
            double cantidadPesos;
            cantidadPesos =  nuevoPeso.GetCantidad();
            Console.WriteLine(cantidadPesos);
            Console.ReadKey();
            Dolar nuevoDolar = new Dolar(100);
            Euro nuevoEuro = new Euro(100);
           
        }
    }
}
