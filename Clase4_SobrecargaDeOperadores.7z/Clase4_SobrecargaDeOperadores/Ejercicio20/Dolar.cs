﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio20
{
    public class Dolar
    {
        double cantidad;
        private static double cotizRespecDolar;
        Dolar()
        {
            cotizRespecDolar = 1;
        }

        public  Dolar(double cantidad) : this()
        {
            this.cantidad = cantidad;
        }
        public Dolar(double cantidad, float cotizacion)
        {
            cotizRespecDolar = cotizacion;
        }

        public double GetCantidad()
        {
            return this.cantidad;
        }

        static public float GetCotizacion()
        {
            return (float)cotizRespecDolar;
        }

        public static explicit operator Euro(Dolar dolares)
        {
            double cotizacion = Euro.GetCotizacion();
             dolares.cantidad = dolares.cantidad * cotizacion;
            
            return new Euro(dolares.cantidad);
        }

        public static explicit operator Peso(Dolar dolares)
        {
            double cotizacion = Pesos.GetCotizacion();
            dolares.cantidad = dolares.cantidad * cotizacion;
        }




    }
}
