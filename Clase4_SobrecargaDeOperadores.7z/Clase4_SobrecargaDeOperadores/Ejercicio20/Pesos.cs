﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio20
{
    class Pesos
    {
         double cantidad;
        private static double cotizRespecDolar;
        Pesos()
        {
            cotizRespecDolar =  Dolar.GetCotizacion() /17.55;
        }

        public Pesos(double cantidad) : this()
        {
            this.cantidad = cantidad;
        }
        public Pesos(double cantidad, float cotizacion)
        {
            cotizRespecDolar = cotizacion;
        }

        public double GetCantidad()
        {
            return this.cantidad;
        }

        static public float GetCotizacion()
        {
            return (float)cotizRespecDolar;
        }

    }

}
