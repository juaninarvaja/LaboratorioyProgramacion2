﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio20
{
    public class Euro
    {
        double cantidad;
        private static double cotizRespecDolar;

        Euro()
        {
            cotizRespecDolar =  1.3652;
        }

        public Euro(double cantidad) : this()
        {
            this.cantidad = cantidad;
        }
        public Euro(double cantidad, float cotizacion)
        {
            cotizRespecDolar = cotizacion;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }

        static public float GetCotizacion()
        {
            return (float)cotizRespecDolar;
        }



    }
}
