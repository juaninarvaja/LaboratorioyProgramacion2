﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase4_SobrecargaDeOperadores
{
    class Program
    {
        static void Main(string[] args)
        {
            //float resultado =  Sobrecarga.Sumar(1,2);
            //Console.WriteLine(resultado);
            //Console.ReadKey();
            //resultado = 0;
            //resultado = Sobrecarga.Sumar(100, 200);
            //Console.WriteLine(resultado);
            //Console.ReadKey();
            //resultado = Sobrecarga.Sumar(100, 2);
            //Console.WriteLine(resultado);
            //Console.ReadKey();


            //sobrecarga del operador "+"
            //Console.WriteLine((new Metro(5) + new Centimetro(800)).valor);
            //Console.ReadKey();


            if (new Metro(5) == new Centimetro(500))
            {
                Console.WriteLine("es igual");
            }
            if (new Metro(5) != new Centimetro(5800))
            {
                Console.WriteLine("es distinto");
            }

            Console.ReadKey();

        }
    }
}
