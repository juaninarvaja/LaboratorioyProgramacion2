﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase4_SobrecargaDeOperadores
{
    class Sobrecarga
    {
        //public static int Sumar(int a, int b)
        //{      //método con dos parámetros
        //    return a + b;
        //}

        //public static int Sumar(int a, int b, int c)
        //{  //método con tres parámetros
        //    return a + b + c;
        //}

        public static  string tipoNumero;
        public Sobrecarga() : this("Metro") //llamo a una Sobrecargar que recibe un string
        {                                   //
                                           //  |
                                           //  |
        }                                  //  \/ esta
        public Sobrecarga(string tipo)
        {
            tipoNumero = tipo; 
        }
     
        public static float Sumar(int a, int b)
        {   //método con dos parámetros
            if (tipoNumero == "Metro")
                return (a + b) * 100;
            else
                return (a + b);
        }

   
        public static float Sumar(float a, float b)
        {   //método con dos parámetros
            if (tipoNumero == "Metro")
                return (a + b) / 100;     //de tipo float		
            else
                return (a + b) / 1000;
        }
       
        public static float Sumar(float a, int b)
        {   //método con dos parámetros
            return a + (b*100);     //de tipo float		
        }

        public static float Sumar(int a, float b)
        {   //método con dos parámetros
            return b +(a*100);     //de tipo float		
        }

    }
}
