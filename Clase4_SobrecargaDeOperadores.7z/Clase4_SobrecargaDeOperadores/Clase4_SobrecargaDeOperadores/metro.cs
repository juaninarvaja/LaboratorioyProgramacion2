﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase4_SobrecargaDeOperadores
{
    class Metro
    {
        public double valor;


        public Metro(double valor)
        {
            this.valor = valor;
        }
        public static Metro operator +(Metro metro, Centimetro centimetro)
        {
            metro.valor += centimetro.valor / 100;
            return metro;
        }
        public static bool operator ==(Metro metro, Centimetro centimetro)
        {
            if (metro.valor == (centimetro.valor / 100))
                return true;
            else
                return false;
        }
        public static bool operator !=(Metro metro, Centimetro centimetro)
        {
            if (metro.valor == (centimetro.valor / 100))
                return false;
            else
                return true;
        }





    }
}
