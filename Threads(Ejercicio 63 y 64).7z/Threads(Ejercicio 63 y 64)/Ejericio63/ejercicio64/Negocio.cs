﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ejercicio64
{
    public class Negocio
    {
        Caja caja1;
        Caja caja2;
        public List<string> clientes;

        //Thread tCaja1;
        //Thread tCaja2;

        public Negocio(Caja c1, Caja c2)
        {
            clientes = new List<string>();
            caja1 = c1;
            caja2 = c2;
            //tCaja1.Name = "Caja 1";
            //tCaja2.Name = "Caja 2";
        }
        #region propiedades
        Caja Caja1
        {
            get { return caja1; }
        }
        Caja Caja2
        {
            get { return caja2; }
        }
        List<string> Clientes
        {
            get { return clientes; }
        }

        #endregion

        //        El método AsignarCaja deberá imprimir el mensaje "Asignando cajas..." cuando sea
        //invocado, recorrer la lista de clientes y asignar a cada cliente en la fila de la caja que menos
        //clientes tenga en ese momento.
        public void AsignarCaja()
        {
            Console.WriteLine("Asignando cajas....");
            foreach (string cl in clientes)
            {
                if (this.caja1.filaclientes.Count > this.caja2.filaclientes.Count)
                {
                    Caja2.filaclientes.Add(cl);
                }
                else Caja1.filaclientes.Add(cl);
                Thread.Sleep(1000);
            }

          

        }
    }
}
