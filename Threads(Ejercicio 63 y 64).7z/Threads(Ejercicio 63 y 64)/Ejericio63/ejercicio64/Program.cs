﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ejercicio64
{
    class Program
    {
        static void Main(string[] args)
        {
            Caja c1 = new Caja();
            Caja c2 = new Caja();
            Negocio n1 = new Negocio(c1, c2);
            n1.clientes.Add("Un Cliente");
            n1.clientes.Add("Dos Cliente");
            n1.clientes.Add("Tres Cliente");
            n1.clientes.Add("Cuatro Cliente");
            n1.clientes.Add("Cinco Cliente");
            n1.clientes.Add("Seis Cliente");
            Thread TAsignarCajas = new Thread(n1.AsignarCaja);
            Thread TAtenderCaja1 = new Thread(c1.AtenderClientes);
            Thread TAtenderCaja2 = new Thread(c2.AtenderClientes);
            TAtenderCaja1.Name = "Caja 1";
            TAtenderCaja2.Name = "Caja 2";

            TAsignarCajas.Start();
            TAsignarCajas.Join(); //no sigue el programa hasta q no termine este hilo
            TAtenderCaja1.Start();
            TAtenderCaja2.Start();
            
            Console.WriteLine("");
            Console.ReadKey();
            //TAsignarCajas.Abort();
            //TAtenderCaja1.Abort();
            //TAtenderCaja2.Abort();

        }
    }
}
