﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ejercicio64
{
    public class Caja
    {
        public List<string> filaclientes;

        public  Caja()
        {
            this.filaclientes = new List<string>();
        }

        List<string> FilaClientes
        {
            get
            {
                return this.filaclientes;
            }
        }

        public void AtenderClientes()
        {
            //            . El método AtenderClientes deberá recorrer la fila de clientes e ir imprimiendo el nombre del
            //cliente que se está atendiendo junto con el número de caja que será previamente seteado
            //en la propiedad "Name" del thread. 
            foreach (string clientes in this.filaclientes)
            {
                Console.WriteLine("Cliente: " + clientes + "       En: " + Thread.CurrentThread.Name);
                Thread.Sleep(2000);
            }
          

        }


    }

}
