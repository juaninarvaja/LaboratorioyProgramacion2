﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejericio63
{
    public partial class Form1 : Form
    {
        Thread tLabel;
        public Form1()
        {
            InitializeComponent();  
            tLabel = new Thread(new ParameterizedThreadStart(AsignarHora));
        }

        private void AsignarHora(object fechaAhora)
        {
            DateTime fecha = (DateTime)fechaAhora;
            while (true)
            {
                MostrarHora(fecha);
                Thread.Sleep(1000);
                fecha = DateTime.Now;
            }
            



        }

        private void MostrarHora(DateTime fecha)
        {
            if (this.lblHora.InvokeRequired)
            {
                this.lblHora.BeginInvoke((MethodInvoker)delegate
                {
                    this.lblHora.Text = fecha.ToString();

                });
            }
            else { this.lblHora.Text = fecha.ToString(); }
        }
           
        

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DateTime fecha = DateTime.Now;
            tLabel.Start(fecha);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

            if (tLabel.IsAlive)
            {
                tLabel.Abort();
            }
            
        }
    }
}
