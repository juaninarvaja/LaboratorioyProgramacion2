﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_6
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            
            Console.WriteLine("ingrese el año");
            string  strNumero= Console.ReadLine();

            bool validInt = int.TryParse(strNumero, out numero);
            if(validInt != false)
            {
                if(numero%4 == 0 && numero%400 == 0)
                {
                    Console.WriteLine("es bisciesto");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine(" no es bisciesto");
                    Console.ReadKey();
                }


            }



        }
    }
}
