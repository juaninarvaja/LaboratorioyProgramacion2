﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio4
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int cantidad = 0;
            int divisor;
            int acumulador;
            for (numero = 1; cantidad != 4; numero++)
            {
                acumulador = 0;
                for(divisor = 1; divisor < numero; divisor++)
                {
                    if(numero%divisor == 0)
                    {
                        acumulador = acumulador + divisor;
                    }

                }
                if(acumulador == numero)
                {
                    cantidad++;
                    Console.WriteLine(numero);
                    Console.ReadKey();
                }

                

            }





        }
    }
}
