﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_7
{
    class Program
    {
        static void Main(string[] args)
        {
            int dia;
            int mes;
            int anio;

            Console.WriteLine("ingrese el dia");
            string strdia = Console.ReadLine();
            Console.WriteLine("ingrese el mes");
            string strmes = Console.ReadLine();
            Console.WriteLine("ingrese el año");
            string stranio = Console.ReadLine();

            bool validDia = int.TryParse(strdia, out dia);
            bool validAnio = int.TryParse(stranio, out anio);
            bool validMes = int.TryParse(strmes, out mes);
            DateTime fechaActual = DateTime.Now;
            
           
            if (validDia != false && validMes != false && validAnio != false)
            {
                int anioActual = fechaActual.Year;
                int mesActual = fechaActual.Month;
                int diaActual = fechaActual.Day;
                int i;
                int cantidadBisiestos = 0;
                for (i = anioActual; i < anio; i--)
                {
                    if (i % 4 == 0 && i % 400 == 0)
                    {
                        cantidadBisiestos++;
                    }
                }
                int difAnios;
                int difMeses;
                int difDias;

                difAnios = anioActual - anio;
                difMeses = mesActual - mes;
                difDias = diaActual - dia;

                int acumuladorDias = 0;
                if (difAnios > 0)
                {
                    acumuladorDias = acumuladorDias + (365 * difAnios) + cantidadBisiestos;


                }

                /*
                DateTime fechaIngresada = new DateTime(anio,mes,dia);
                TimeSpan diferencia = fechaActual - fechaIngresada;
                long diferenciaEnDias = diferencia.Days;
                Console.Write("la diferencia es de" + diferenciaEnDias + "dias");
                Console.ReadKey();
                
                    */ 
            }

        }
    }
}
