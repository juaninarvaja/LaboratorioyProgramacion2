﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "ejercicio num 1";
            int numero;
            int contador = 0;
            int minimo = int.MaxValue;
            int maximo = int.MinValue;
            int acumulador = 0;
            float promedio;


            while (contador < 5)
            {
                Console.WriteLine("ingrese el numero" +  contador);
             
                numero = int.Parse(Console.ReadLine());
                Console.WriteLine("ingresaste" + numero);
             
                if(numero > maximo )
                {
                    maximo = numero;
                }
                if(numero < minimo)
                {
                    minimo = numero;
                }
                acumulador = acumulador + numero;
                contador++;

            }
            promedio = acumulador / (float)contador;
            Console.WriteLine("el maximo es" + maximo);
            Console.WriteLine("el minimo es" + minimo);
            Console.WriteLine("el promedio es" + promedio);
            Console.ReadKey();


        }
    }
}
