﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjerciciosClase3
{
    public class Alumno
    {
        byte notaUno;
        byte notaDos;
        int notaFinal;
        public string apellido;
        public int legajo;
        public string nombre;

        public void Estudiar(byte notaA, byte notaB)
        {
            notaUno = notaA;
            notaDos = notaB;

        } 
         public void CalcularFinal()
        {
            if (notaUno > 3 && notaDos > 3)
            {
                Random unRandom = new Random();
                notaFinal = (byte)unRandom.Next(1, 10);
               
            }
            else
            {
                 notaFinal = -1;
            }
                
        }
        public string Mostrar()
        {
            if (notaUno > 3 && notaDos > 3)
            {
                string respuesta;
                 respuesta =  string.Format("{0}{1}{2}", nombre,apellido,notaFinal);
                return respuesta;
            }
            else
            {
                string respuesta;
                respuesta = "no llego al final";
                return respuesta;

            }

        }

    }
}
