﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjerciciosClase3
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno unAlumno = new Alumno();
            Alumno dosAlumno = new Alumno();
            Alumno tresAlumno = new Alumno();
            unAlumno.nombre = "jose";
            dosAlumno.nombre = "matias";
            tresAlumno.nombre = "juan";
            unAlumno.apellido = "defeo";
            dosAlumno.apellido = "gaston";
            tresAlumno.apellido = "narvaja";
            unAlumno.legajo = 1001;
            dosAlumno.legajo = 1002;
            tresAlumno.legajo = 1003;
       
            unAlumno.Estudiar(1, 3);
            dosAlumno.Estudiar(5, 5);
            tresAlumno.Estudiar(10, 10);
            unAlumno.CalcularFinal();
            string finalUno;
            string finalDos;
            string finalTres;
            
            finalUno = unAlumno.Mostrar();
            Console.WriteLine(finalUno);
            Console.ReadKey();

            dosAlumno.CalcularFinal();
           finalDos = dosAlumno.Mostrar();
            Console.WriteLine(finalDos);
            Console.ReadKey();

            tresAlumno.CalcularFinal();
            finalTres = tresAlumno.Mostrar();
            
            Console.WriteLine(finalTres);
            Console.ReadKey();
        }
    }
}
