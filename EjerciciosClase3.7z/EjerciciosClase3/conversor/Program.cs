﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conversor
{
    //ejercicio 13
    class Program
    {
        static void Main(string[] args)
        {
            //string resultado;
            //double entero;

            //resultado = DecimalBinario(9);
            //Console.WriteLine("el resultado es" + resultado);
            //Console.ReadKey();
            //entero = BinarioDecimal("1010");
            //Console.WriteLine("el resultado entero es" + entero);
            //Console.ReadKey();
            //double ladoCuadrado = 4;
            //double areaCuadrado;
            //areaCuadrado = CalculoDeArea.CalcularCuadrado(ladoCuadrado);
            //Console.WriteLine("el area del cuadrado es: " + areaCuadrado);
            //Console.ReadKey();
            //double baseTriangulo = 10;
            //double alturaTriangulo = 10;
            //double areaTriangulo;
            //areaTriangulo= CalculoDeArea.CalcularTriangulo(baseTriangulo,alturaTriangulo);
            //Console.WriteLine("el area del triangulo es: " + areaTriangulo);
            //Console.ReadKey();
            //double radioCirculo = 10;
            //double areaCirculo;
            //areaCirculo = CalculoDeArea.CalcularCirculo(radioCirculo);
            //Console.WriteLine("el area del ciruclo es: " + areaCirculo);
            //Console.ReadKey();
            double resultado;
            resultado = Calculadora.Calcular(1, 2, '*');
            Console.WriteLine("el resultado de la cuenta es " + resultado);
            Console.ReadKey();







        }
        public static string DecimalBinario(double numero)
        {
            int Num = Convert.ToInt32(numero);
            if (Num > 0)
            {
                String cad = "";
                while (Num > 0)
                {
                    if (Num % 2 == 0)
                    {
                        cad = "0" + cad;
                    }
                    else
                    {
                        cad = "1" + cad;
                    }
                    Num = (int)(Num / 2);
                }
                return cad;
            }
            else
            {
                if (Num == 0)
                {
                    Console.WriteLine("0");
                    string resp;
                    resp = "0";
                    return resp;
                }
                else
                {
                    string respInvd = "invalid";
                    return respInvd;
                }
            }


        }

        public static double BinarioDecimal(string binario)
        {
            int exponente = binario.Length - 1;
            double num_decimal = 0;

            for (int i = 0; i < binario.Length; i++)
            {
                if (int.Parse(binario.Substring(i, 1)) == 1)
                {
                    num_decimal = num_decimal + int.Parse(System.Math.Pow(2, double.Parse(exponente.ToString())).ToString());
                }
                exponente--;
            }
            return num_decimal;



        }



    }
}
