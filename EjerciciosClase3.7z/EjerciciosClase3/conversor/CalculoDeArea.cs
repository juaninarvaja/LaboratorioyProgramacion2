﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conversor
{
    class CalculoDeArea
    {
        //        a. double CalcularCuadrado(double)
        //b. double CalcularTriangulo(double, double)
        //c. double CalcularCirculo(double)

        public static double CalcularCuadrado(double lado)
        {
            double area;
            area = Math.Pow(lado, 2);
            return area;
        }
        public static double CalcularTriangulo(double largoBase, double largoAltura)
        {
            double area;
            area = (largoBase * largoAltura) / 2;
            return area;
        }
        public static double CalcularCirculo(double radio)
        {
            double area;
          
            area = Math.PI * Math.Pow(radio,2);
            return area;
        }
    }

 

}
