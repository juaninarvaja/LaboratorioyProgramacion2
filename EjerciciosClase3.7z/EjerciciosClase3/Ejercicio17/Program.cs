﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio17
{
    class Program
    {
        static void Main(string[] args)
        {
            Boligrafo unBoligrafo = new Boligrafo(100,ConsoleColor.Blue);
            Boligrafo dosBoligrafo = new Boligrafo(50,ConsoleColor.Red);
           
            


        }
    }
}
