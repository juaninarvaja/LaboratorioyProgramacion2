﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio17
{

    class Boligrafo
    {
        const short cantidadTintaMaxima = 100;
        ConsoleColor color;
        short tinta;

        public Boligrafo(short cantTinta, ConsoleColor colorTinta)
        {
            color = colorTinta;
            tinta = cantTinta;
        }


        public ConsoleColor GetColor()
        {
            return color;
        }
        public short GetTinta()
        {
            return tinta;
        }
        /// <summary>
        /// Funcion para agregar o restar tinta, positivo si quiero cargar, negativo si quiero sacar
        /// </summary>
        /// <param name="CantTinta"></param>
        /// cantidad de tinta a agregar
        private void SetTinta(short CantTinta)
        {
            if((tinta += CantTinta) >= cantidadTintaMaxima && (tinta+=CantTinta) <= 0)
            {
                tinta += CantTinta;
                
            }
     
        }
        public void Recargar()
        {
            tinta = cantidadTintaMaxima;
        }
        public bool Pintar(int gasto, out string dibujo)
        {
            
        }

    }
}
